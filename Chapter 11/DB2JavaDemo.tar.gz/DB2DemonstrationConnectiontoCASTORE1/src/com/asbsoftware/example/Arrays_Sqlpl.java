package com.asbsoftware.example;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.Connection;
//For the latest information on programming, building, and running DB2     
//applications, visit the DB2 application development website:             
//http://www.software.ibm.com/data/db2/udb/ad   
//
//*****************************************************************************
//
//ASB Software Development Code Example
//
//*****************************************************************************
//Select the data from the table "CAUSER.D_DMTASK".
//*****************************************************************************
//import java.sql.*;


public class Arrays_Sqlpl  
	{
	  public static void main(String argv[])
	  {
	   String url = "jdbc:db2://localhost:50000/CASTORE1:user=db2inst1;password=filenet;";
        Connection connection = null;
	    try
	    {
	      // connect to the db
	      Class.forName("com.ibm.db2.jcc.DB2Driver").newInstance();
	      // connect to the 'CASTORE1' database
	      connection = java.sql.DriverManager.getConnection( url );
	      Statement stmt=connection.createStatement();
	      
	//*****************************************************************************
	//  Select the data from the table "CAUSER.D_DMTASK".
	//*****************************************************************************      
	   // DMTASK_KEY BIGINT  DMTASKTYPE_KEY INTEGER TASKID CHAR
	      String selectStmt = "SELECT * FROM CAUSER.D_DMTASK";
	      ResultSet rs = (ResultSet) stmt.executeQuery(selectStmt);
	      System.out.println("DMTASK_KEY     DMTASKTYPE_KEY" + "\t" +  "TASKID");
	      while(rs.next())
	      {
	       System.out.println( "\t" + rs.getLong(1) +  "\t"  + rs.getInt(2) + "\t" +  "\t" + rs.getString(3));
	       }
	      // cleanup
	      stmt.close();
	      connection.close();
	    }
	    catch (Exception e)
	    {
	      try
	      {
	    	  connection.rollback();
	    	  connection.close();
	      }
	      catch (Exception x)
	      { }

	      e.printStackTrace();
	    }
	  } // end main
	} // end Arrays_Sqlpl
